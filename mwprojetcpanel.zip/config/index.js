export const site_api = "https://www.wp.cvgm0689.odns.fr/wp-json/wp/v2"
export const site_url = "https://www.cvgm0689.odns.fr"