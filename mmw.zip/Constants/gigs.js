export const gigs = [
    
    {
        nameOfEvent: 'Blue Monday Concert Series', 
        location: 'Lille, FR', 
        date: '11/21/2022',
        ticketLink: 'http://www.facebook.com/BlueMondayMission/'
    },
    {
        nameOfEvent: 'Blue Monday Concert Series',
        location: 'Lille, FR',
        date: '11/21/2022',
        ticketLink: 'http://www.facebook.com/BlueMondayMission/'
    },
    {
        nameOfEvent: `Blue Monday Concert Series`,
        location: 'Lille, FR',
        date: '11/21/2022',
        ticketLink: 'http://www.facebook.com/BlueMondayMission/'
    },
]
