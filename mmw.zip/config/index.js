export const site_api = "https://www.wp.michaelmudcatward.com/wp-json/wp/v2"
export const site_url = "https://www.michaelmudcatward.com"