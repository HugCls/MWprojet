(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9180:
/***/ ((module) => {

// Exports
module.exports = {
	"logo": "Layout_logo__dBXl_",
	"footerlogo": "Layout_footerlogo__CNf1V",
	"logoMiddle": "Layout_logoMiddle__rhjkh",
	"navbar": "Layout_navbar__OuN2_",
	"navlinks": "Layout_navlinks__nlyQo",
	"footermain": "Layout_footermain__5Zl7q",
	"footercontent": "Layout_footercontent__VJJFG",
	"footertable": "Layout_footertable___M2sh",
	"listHeading": "Layout_listHeading__716AN",
	"css-yi1c6h": "Layout_css-yi1c6h__JRJGB"
};


/***/ }),

/***/ 8930:
/***/ ((module) => {

"use strict";
module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 5368:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2452:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "styled-components"
const external_styled_components_namespaceObject = require("styled-components");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./ThemeConfig.js

const GlobalStyles = external_styled_components_namespaceObject.createGlobalStyle`
  body {
    background: ${({ theme  })=>theme.body};
    color: ${({ theme  })=>theme.text};
    font-family: Tahoma, Helvetica, Arial, Roboto, sans-serif;
    transition: all 0.20s linear;
  }
`;

;// CONCATENATED MODULE: ./Constants/theme.js
const lightTheme = {
    name: "light",
    body: "#fefefe",
    text: "#363537",
    subtext: "#4f4f4f",
    secondary: "#d7f7f5",
    tertiary: "#75cac3",
    accent: "#263859",
    boxShadow: "0px 2px 10px -2px rgba(134, 134, 134, 0.5)",
    contrastText: "#FAFAFA",
    footerColor: "#F0F0F0"
};
const darkTheme = {
    name: "dark",
    body: "#17223b",
    text: "#FAFAFA",
    subtext: "#D0D0D0",
    secondary: "#263859",
    tertiary: "#A2AAB9",
    accent: "#d7f7f5",
    boxShadow: "0px 2px 10px -2px rgba(51, 51, 51, 0.5)",
    contrastText: "#101010",
    footerColor: "#16161D"
};

// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: ./styles/Layout.module.css
var Layout_module = __webpack_require__(9180);
var Layout_module_default = /*#__PURE__*/__webpack_require__.n(Layout_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
;// CONCATENATED MODULE: ./Components/Navlinks.jsx





const Navlinks = ()=>{
    const router = (0,router_namespaceObject.useRouter)();
    const { 0: activeLink , 1: setActiveLink  } = (0,external_react_.useState)("/");
    (0,external_react_.useEffect)(()=>{
        setActiveLink(router.asPath);
    }, [
        router.asPath
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Layout_module_default()).navlinks,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        style: {
                            opacity: activeLink === "/" || activeLink === "/#gigs" ? "100%" : "80%"
                        },
                        children: "Home"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Layout_module_default()).navlinks,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/#about",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        style: {
                            opacity: activeLink === "/#about" ? "100%" : "80%"
                        },
                        children: "About"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Layout_module_default()).navlinks,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/media",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        style: {
                            opacity: activeLink === "/gigs" ? "100%" : "80%"
                        },
                        children: "Media"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Layout_module_default()).navlinks,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/contact",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        style: {
                            opacity: activeLink === "/contact" ? "100%" : "80%"
                        },
                        children: "Contact"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Components_Navlinks = (Navlinks);

// EXTERNAL MODULE: ./Constants/userinfo.js
var userinfo = __webpack_require__(2107);
;// CONCATENATED MODULE: ./Components/Navbar.jsx








const Navbar = ({ toggleTheme , currentTheme  })=>{
    const [drawerVisible] = (0,react_.useMediaQuery)("(max-width: 950px)");
    const { 0: sticky , 1: setSticky  } = (0,external_react_.useState)(false);
    const handleScroll = ()=>{
        const offset = window.scrollY;
        if (offset > 0) {
            setSticky(true);
        } else {
            setSticky(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", handleScroll);
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Layout_module_default()).navbar,
        style: {
            width: "100%",
            backgroundColor: currentTheme.secondary,
            boxShadow: currentTheme.boxShadow,
            position: sticky ? "fixed" : "static"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "space-evenly",
                    alignItems: "baseline",
                    marginBottom: !drawerVisible ? "0" : "10px"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: (Layout_module_default()).logo,
                                children: [
                                    userinfo/* userinfo.logoTextFn */.ug.logoTextFn,
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: (Layout_module_default()).logoMiddle,
                                        children: [
                                            " ",
                                            "\xa0 \xa0",
                                            userinfo/* userinfo.logoTextMn */.ug.logoTextMn,
                                            " \xa0 \xa0"
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (Layout_module_default()).logo,
                                        children: userinfo/* userinfo.logoTextLn */.ug.logoTextLn
                                    })
                                ]
                            })
                        })
                    }),
                    !drawerVisible ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            display: "flex"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Components_Navlinks, {})
                    }) : null,
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Switch, {
                        id: "dark-mode",
                        colorScheme: "purple",
                        size: !drawerVisible ? "lg" : "md",
                        isChecked: currentTheme.name === "dark",
                        onChange: ()=>toggleTheme()
                    })
                ]
            }),
            drawerVisible ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            display: "flex",
                            justifyContent: "space-evenly",
                            marginTop: "10px"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Components_Navlinks, {})
                    })
                ]
            }) : null
        ]
    });
};
/* harmony default export */ const Components_Navbar = (Navbar);

;// CONCATENATED MODULE: ./Components/Footer.jsx




const Footer = ({ currentTheme  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Layout_module_default()).footermain,
        style: {
            backgroundColor: currentTheme.footerColor,
            color: currentTheme.subtext
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Layout_module_default()).footertable,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: (Layout_module_default()).footerlogo,
                                children: userinfo/* userinfo.logoText */.ug.logoText
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (Layout_module_default()).listHeading,
                                children: "Socials"
                            }),
                            userinfo/* userinfo.socials */.ug.socials ? userinfo/* userinfo.socials.map */.ug.socials.map((social, key)=>{
                                return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: social.link,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: social.type
                                        })
                                    })
                                }, key);
                            }) : null,
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `mailto:${userinfo/* userinfo.contact.email */.ug.contact.email ? userinfo/* userinfo.contact.email */.ug.contact.email : ""}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Mail"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (Layout_module_default()).listHeading,
                                children: "Pages"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Home"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/#about",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "About"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/media",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Media"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/contact",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Contact"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                style: {
                    height: "1px",
                    backgroundColor: currentTheme.subtext,
                    border: "none",
                    opacity: "0.5"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Layout_module_default()).footerbottom,
                        style: {
                            marginTop: "30px"
                        },
                        children: [
                            "Mudcat Ward recommends the bass players\u2019 website for strings and other supplies, Gollihur Music, ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "LLC Phone: 856-292-3194 Email: queries@gollihurmusic.com",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.gollihurmusic.com",
                                target: "_blank",
                                style: {
                                    fontSize: "16px",
                                    color: "#3182ce"
                                },
                                children: "Visit their website"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Layout_module_default()).footerbottom,
                        children: [
                            "Travel easily with your bass with",
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "https://www.travelbass.it/",
                                target: "_blank",
                                style: {
                                    fontSize: "16px",
                                    color: "#3182ce"
                                },
                                children: [
                                    "Travelbass",
                                    " "
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Components_Footer = (Footer);

;// CONCATENATED MODULE: ./Layout.js



const Layout = ({ children , toggleTheme , currentTheme  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Components_Navbar, {
                toggleTheme: toggleTheme,
                currentTheme: currentTheme
            }),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(Components_Footer, {
                currentTheme: currentTheme
            })
        ]
    });
};
/* harmony default export */ const Layout_0 = (Layout);

;// CONCATENATED MODULE: external "aos"
const external_aos_namespaceObject = require("aos");
;// CONCATENATED MODULE: ./pages/_app.js










function MyApp({ Component , pageProps  }) {
    const { 0: theme , 1: setTheme  } = (0,external_react_.useState)("light");
    (0,external_react_.useEffect)(()=>{
        if (localStorage.getItem("theme")) {
            setTheme(localStorage.getItem("theme"));
        } else {
            setTheme("light");
        }
    }, []);
    (0,external_react_.useEffect)(()=>{
        localStorage.setItem("theme", theme);
    }, [
        theme
    ]);
    (0,external_react_.useEffect)(()=>{
        external_aos_namespaceObject.init({
            duration: 500
        });
    }, []);
    const toggleTheme = ()=>{
        theme == "light" ? setTheme("dark") : setTheme("light");
    };
    const currentTheme = theme === "light" ? lightTheme : darkTheme;
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.ChakraProvider, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_styled_components_namespaceObject.ThemeProvider, {
            theme: theme == "light" ? lightTheme : darkTheme,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(GlobalStyles, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Layout_0, {
                    toggleTheme: toggleTheme,
                    currentTheme: currentTheme,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps,
                        currentTheme: currentTheme
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,107], () => (__webpack_exec__(2452)));
module.exports = __webpack_exports__;

})();