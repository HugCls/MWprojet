"use strict";
(() => {
var exports = {};
exports.id = 119;
exports.ids = [119];
exports.modules = {

/***/ 3663:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
;// CONCATENATED MODULE: ./pages/api/discogs.js

const options = {
    method: "GET",
    url: "https://api.discogs.com/artists/1368289/releases",
    params: {
        sort: "year",
        sort_order: "desc",
        per_page: "75"
    },
    headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept",
        Authorization: 'OAuth oauth_consumer_key="", oauth_nonce="neAstJtZ0ElmEYJRTvcV6XZ11TOkrP4T", oauth_signature="HrEx5gGRp3%2FYGfjbXrAPJ1UVoAs%3D", oauth_signature_method="HMAC-SHA1", oauth_timestamp="1663622496", oauth_token="goccowdGLBPzAZlfvRejYDekqKykERVdoNHCEsOA", oauth_version="1.0"'
    }
};
external_axios_namespaceObject.request(options).then(function(response) {
    console.log(response.data);
}).catch(function(error) {
    console.error(error);
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3663));
module.exports = __webpack_exports__;

})();